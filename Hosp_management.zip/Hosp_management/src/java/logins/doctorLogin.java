package logins;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Athul Krishna
 */
@WebService(serviceName = "doctorLogin")
public class doctorLogin {

    @WebMethod(operationName = "login")
    public String login(
            @WebParam(name = "username") String username,
            @WebParam(name = "password") String password) {

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/hospital";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
                // Query to check if the provided credentials match any entry in the adminlogin table
                String query = "SELECT * FROM doctor WHERE username=? AND password=?";

                // Create a PreparedStatement
                try (PreparedStatement pst = conn.prepareStatement(query)) {
                    pst.setString(1, username);
                    pst.setString(2, password);

                    // Execute the query
                    ResultSet rs = pst.executeQuery();

                    // Check if the result set contains any rows (valid credentials)
                    if (rs.next()) {
                        return "Login successful!";
                    } else {
                        return "Invalid username or password!";
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Database connection error: " + ex.getMessage());
            ex.printStackTrace(); // Print the stack trace for detailed error information
            return "Failed to log in due to a database error!";
        }
    }
}
