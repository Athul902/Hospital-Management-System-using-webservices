package objects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "ReportManagement")
public class reportManagement {

    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/hospital";
    String username = "root";
    String password = "";

    // Load the MySQL JDBC driver
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @WebMethod(operationName = "addReport")
    public String addReport(
            @WebParam(name = "report_id") String report_id,
            @WebParam(name = "pre_id") String pre_id,
            @WebParam(name = "pt_id") String pt_id,
            @WebParam(name = "report_date") String report_date,
            @WebParam(name = "report_time") String report_time,
            @WebParam(name = "name") String name,
            @WebParam(name = "age") int age,
            @WebParam(name = "bed_no") String bed_no,
            @WebParam(name = "temp") double temp,
            @WebParam(name = "bp") String bp,
            @WebParam(name = "symptoms") String symptoms,
            @WebParam(name = "medication_report") String medication_report,
            @WebParam(name = "observation_report") String observation_report,
            @WebParam(name = "nurse_id") String nurse_id,
            @WebParam(name = "doc_id") String doc_id) {

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "INSERT INTO report (report_id, pre_id, pt_id, report_date, report_time, name, age, bed_no, temp, bp, symptoms, medication_report, observation_report, nurse_id, doc_id) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, report_id);
            statement.setString(2, pre_id);
            statement.setString(3, pt_id);
            statement.setString(4, report_date);
            statement.setString(5, report_time);
            statement.setString(6, name);
            statement.setInt(7, age);
            statement.setString(8, bed_no);
            statement.setDouble(9, temp);
            statement.setString(10, bp);
            statement.setString(11, symptoms);
            statement.setString(12, medication_report);
            statement.setString(13, observation_report);
            statement.setString(14, nurse_id);
            statement.setString(15, doc_id);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return "Report added successfully!";
            } else {
                return "Failed to add report!";
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to add report due to a database error!";
        }
    }

    @WebMethod(operationName = "deleteReport")
    public String deleteReport(@WebParam(name = "pt_id") String pt_id) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "DELETE FROM report WHERE pt_id = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, pt_id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                return "Report deleted successfully!";
            } else {
                return "Report not found!";
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to delete report due to a database error!";
        }
    }

    @WebMethod(operationName = "updateReport")
    public String updateReport(
            @WebParam(name = "report_id") String report_id,
            @WebParam(name = "field_name") String field_name,
            @WebParam(name = "new_value") String new_value) {

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "UPDATE report SET " + field_name + "=? WHERE report_id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, new_value);
            pst.setString(2, report_id);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                return "Report with ID " + report_id + " - " + field_name + " updated successfully.";
            } else {
                return "No report found with ID " + report_id;
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to update report due to a database error!";
        }
    }

    @WebMethod(operationName = "viewReportDetails")
    public String viewReportDetails(@WebParam(name = "pt_id") String pt_id) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT * FROM report WHERE pt_id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, pt_id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                StringBuilder result = new StringBuilder();
                result.append("Report ID: ").append(rs.getString("report_id")).append("\n")
                        .append("Pre ID: ").append(rs.getString("pre_id")).append("\n")
                        .append("Patient ID: ").append(rs.getString("pt_id")).append("\n")
                        .append("Report Date: ").append(rs.getString("report_date")).append("\n")
                        .append("Report Time: ").append(rs.getString("report_time")).append("\n")
                        .append("Name: ").append(rs.getString("name")).append("\n")
                        .append("Age: ").append(rs.getInt("age")).append("\n")
                        .append("Bed Number: ").append(rs.getString("bed_no")).append("\n")
                        .append("Temperature: ").append(rs.getDouble("temp")).append("\n")
                        .append("Blood Pressure: ").append(rs.getString("bp")).append("\n")
                        .append("Symptoms: ").append(rs.getString("symptoms")).append("\n")
                        .append("Medication Report: ").append(rs.getString("medication_report")).append("\n")
                        .append("Observation Report: ").append(rs.getString("observation_report")).append("\n")
                        .append("Nurse ID: ").append(rs.getString("nurse_id")).append("\n")
                        .append("Doctor ID: ").append(rs.getString("doc_id")).append("\n");
                return result.toString();
            } else {
                return "No report found with ID " + pt_id;
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to retrieve report details due to a database error!";
        }
    }
}
