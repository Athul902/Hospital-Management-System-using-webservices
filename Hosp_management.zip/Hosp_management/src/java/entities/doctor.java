package entities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;


@WebService(serviceName = "DoctorManagement")
public class doctor {

    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/hospital";
    String username = "root";
    String password = "";

    // Load the MySQL JDBC driver
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @WebMethod(operationName = "registerDoctor")
    public String registerDoctor(
            @WebParam(name = "doc_id") String doc_id,
            @WebParam(name = "name") String name,
            @WebParam(name = "dob") String dob,
            @WebParam(name = "gender") String gender,
            @WebParam(name = "phone_no") String phone_no,
            @WebParam(name = "email") String email,
            @WebParam(name = "address") String address,
            @WebParam(name = "medical_degree") String medical_degree,
            @WebParam(name = "specialty") String specialty,
            @WebParam(name = "emp_status") String emp_status,
            @WebParam(name = "start_date") String start_date,
            @WebParam(name = "gov_id") String gov_id,
            @WebParam(name = "username") String uname,
            @WebParam(name = "password") String pass) {

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "INSERT INTO doctor (doc_id, name, dob, gender, phone_no, email, address, medical_degree, specialty, emp_status, start_date, gov_id, username, password) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, doc_id);
            statement.setString(2, name);
            statement.setString(3, dob);
            statement.setString(4, gender);
            statement.setString(5, phone_no);
            statement.setString(6, email);
            statement.setString(7, address);
            statement.setString(8, medical_degree);
            statement.setString(9, specialty);
            statement.setString(10, emp_status);
            statement.setString(11, start_date);
            statement.setString(12, gov_id);
            statement.setString(13, uname);
            statement.setString(14, pass);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return "Doctor registered successfully!";
            } else {
                return "Failed to register doctor!";
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to register doctor due to a database error!";
        }
    }

    @WebMethod(operationName = "deleteDoctor")
    public String deleteDoctor(@WebParam(name = "doc_id") String doc_id) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "DELETE FROM doctor WHERE doc_id = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, doc_id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                return "Doctor deleted successfully!";
            } else {
                return "Doctor not found!";
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to delete doctor due to a database error!";
        }
    }

    @WebMethod(operationName = "updateDoctor")
    public String updateDoctor(
            @WebParam(name = "doc_id") String doc_id,
            @WebParam(name = "field_name") String field_name,
            @WebParam(name = "new_value") String new_value) {

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "UPDATE doctor SET " + field_name + "=? WHERE doc_id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, new_value);
            pst.setString(2, doc_id);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                return "Doctor with ID " + doc_id + " - " + field_name + " updated successfully.";
            } else {
                return "No doctor found with ID " + doc_id;
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to update doctor due to a database error!";
        }
    }

    @WebMethod(operationName = "viewDoctorDetails")
    public String viewDoctorDetails(@WebParam(name = "doc_id") String doc_id) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT * FROM doctor WHERE doc_id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, doc_id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                StringBuilder result = new StringBuilder();
                result.append("Doctor ID: ").append(rs.getString("doc_id")).append("\n")
                        .append("Name: ").append(rs.getString("name")).append("\n")
                        .append("Date of Birth: ").append(rs.getString("dob")).append("\n")
                        .append("Gender: ").append(rs.getString("gender")).append("\n")
                        .append("Phone Number: ").append(rs.getString("phone_no")).append("\n")
                        .append("Email: ").append(rs.getString("email")).append("\n")
                        .append("Address: ").append(rs.getString("address")).append("\n")
                        .append("Medical Degree: ").append(rs.getString("medical_degree")).append("\n")
                        .append("Specialty: ").append(rs.getString("specialty")).append("\n")
                        .append("Employment Status: ").append(rs.getString("emp_status")).append("\n")
                        .append("Start Date: ").append(rs.getString("start_date")).append("\n")
                        .append("Government ID: ").append(rs.getString("gov_id")).append("\n")
                        .append("Username: ").append(rs.getString("username")).append("\n")
                        .append("Password: ").append(rs.getString("password")).append("\n");
                return result.toString();
            } else {
                return "No doctor found with ID " + doc_id;
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to retrieve doctor details due to a database error!";
        }
    }
}
