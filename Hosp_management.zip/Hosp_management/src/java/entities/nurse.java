package entities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "NurseManagement")
public class nurse {

    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/hospital";
    String username = "root";
    String password = "";

    // Load the MySQL JDBC driver
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @WebMethod(operationName = "registerNurse")
    public String registerNurse(
            @WebParam(name = "nurse_id") String nurse_id,
            @WebParam(name = "name") String name,
            @WebParam(name = "dob") String dob,
            @WebParam(name = "gender") String gender,
            @WebParam(name = "phone_no") String phone_no,
            @WebParam(name = "email") String email,
            @WebParam(name = "address") String address,
            @WebParam(name = "nursing_degree") String nursing_degree,
            @WebParam(name = "nursing_college") String nursing_college,
            @WebParam(name = "emp_status") String emp_status,
            @WebParam(name = "start_date") String start_date,
            @WebParam(name = "gov_id") String gov_id,
            @WebParam(name = "username") String uname,
            @WebParam(name = "password") String pass) {

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "INSERT INTO nurse (nurse_id, name, dob, gender, phone_no, email, address, nursing_degree, nursing_college, emp_status, start_date, gov_id, username, password) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, nurse_id);
            statement.setString(2, name);
            statement.setString(3, dob);
            statement.setString(4, gender);
            statement.setString(5, phone_no);
            statement.setString(6, email);
            statement.setString(7, address);
            statement.setString(8, nursing_degree);
            statement.setString(9, nursing_college);
            statement.setString(10, emp_status);
            statement.setString(11, start_date);
            statement.setString(12, gov_id);
            statement.setString(13, uname);
            statement.setString(14, pass);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return "Nurse registered successfully!";
            } else {
                return "Failed to register nurse!";
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to register nurse due to a database error!";
        }
    }

    @WebMethod(operationName = "deleteNurse")
    public String deleteNurse(@WebParam(name = "nurse_id") String nurse_id) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "DELETE FROM nurse WHERE nurse_id = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, nurse_id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                return "Nurse deleted successfully!";
            } else {
                return "Nurse not found!";
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to delete nurse due to a database error!";
        }
    }

    @WebMethod(operationName = "updateNurse")
    public String updateNurse(
            @WebParam(name = "nurse_id") String nurse_id,
            @WebParam(name = "field_name") String field_name,
            @WebParam(name = "new_value") String new_value) {

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "UPDATE nurse SET " + field_name + "=? WHERE nurse_id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, new_value);
            pst.setString(2, nurse_id);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                return "Nurse with ID " + nurse_id + " - " + field_name + " updated successfully.";
            } else {
                return "No nurse found with ID " + nurse_id;
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to update nurse due to a database error!";
        }
    }

    @WebMethod(operationName = "viewNurseDetails")
    public String viewNurseDetails(@WebParam(name = "nurse_id") String nurse_id) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT * FROM nurse WHERE nurse_id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, nurse_id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                StringBuilder result = new StringBuilder();
                result.append("Nurse ID: ").append(rs.getString("nurse_id")).append("\n")
                        .append("Name: ").append(rs.getString("name")).append("\n")
                        .append("Date of Birth: ").append(rs.getString("dob")).append("\n")
                        .append("Gender: ").append(rs.getString("gender")).append("\n")
                        .append("Phone Number: ").append(rs.getString("phone_no")).append("\n")
                        .append("Email: ").append(rs.getString("email")).append("\n")
                        .append("Address: ").append(rs.getString("address")).append("\n")
                        .append("Nursing Degree: ").append(rs.getString("nursing_degree")).append("\n")
                        .append("Nursing College: ").append(rs.getString("nursing_college")).append("\n")
                        .append("Employment Status: ").append(rs.getString("emp_status")).append("\n")
                        .append("Start Date: ").append(rs.getString("start_date")).append("\n")
                        .append("Government ID: ").append(rs.getString("gov_id")).append("\n")
                        .append("Username: ").append(rs.getString("username")).append("\n")
                        .append("Password: ").append(rs.getString("password")).append("\n");
                return result.toString();
            } else {
                return "No nurse found with ID " + nurse_id;
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to retrieve nurse details due to a database error!";
        }
    }
}
