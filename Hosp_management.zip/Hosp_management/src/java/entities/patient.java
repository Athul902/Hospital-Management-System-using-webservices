package entities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "PatientManagement")
public class patient {

    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/hospital";
    String username = "root";
    String password = "";

    // Load the MySQL JDBC driver
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @WebMethod(operationName = "registerPatient")
    public String registerPatient(
            @WebParam(name = "pt_id") String pt_id,
            @WebParam(name = "name") String name,
            @WebParam(name = "dob") String dob,
            @WebParam(name = "gender") String gender,
            @WebParam(name = "marital_status") String marital_status,
            @WebParam(name = "nationality") String nationality,
            @WebParam(name = "occupation") String occupation,
            @WebParam(name = "home_add") String home_add,
            @WebParam(name = "phone_no") String phone_no,
            @WebParam(name = "email") String email,
            @WebParam(name = "visit_date") String visit_date,
            @WebParam(name = "visit_time") String visit_time,
            @WebParam(name = "name_emg_contact") String name_emg_contact,
            @WebParam(name = "relation_emg_contact") String relation_emg_contact,
            @WebParam(name = "emg_contact_no") String emg_contact_no,
            @WebParam(name = "gov_id") String gov_id,
            @WebParam(name = "patient_note") String patient_note) {

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "INSERT INTO patient (pt_id, name, dob, gender, marital_status, nationality, occupation, home_add, phone_no, email, visit_date, visit_time, name_emg_contact, relation_emg_contact, emg_contact_no, gov_id, patient_note) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, pt_id);
            statement.setString(2, name);
            statement.setString(3, dob);
            statement.setString(4, gender);
            statement.setString(5, marital_status);
            statement.setString(6, nationality);
            statement.setString(7, occupation);
            statement.setString(8, home_add);
            statement.setString(9, phone_no);
            statement.setString(10, email);
            statement.setString(11, visit_date);
            statement.setString(12, visit_time);
            statement.setString(13, name_emg_contact);
            statement.setString(14, relation_emg_contact);
            statement.setString(15, emg_contact_no);
            statement.setString(16, gov_id);
            statement.setString(17, patient_note);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return "Patient registered successfully!";
            } else {
                return "Failed to register patient!";
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to register patient due to a database error!";
        }
    }

    @WebMethod(operationName = "deletePatient")
    public String deletePatient(@WebParam(name = "pt_id") String pt_id) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "DELETE FROM patient WHERE pt_id = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, pt_id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                return "Patient deleted successfully!";
            } else {
                return "Patient not found!";
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to delete patient due to a database error!";
        }
    }

    @WebMethod(operationName = "updatePatient")
    public String updatePatient(
            @WebParam(name = "pt_id") String pt_id,
            @WebParam(name = "field_name") String field_name,
            @WebParam(name = "new_value") String new_value) {

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "UPDATE patient SET " + field_name + "=? WHERE pt_id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, new_value);
            pst.setString(2, pt_id);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                return "Patient with ID " + pt_id + " - " + field_name + " updated successfully.";
            } else {
                return "No patient found with ID " + pt_id;
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to update patient due to a database error!";
        }
    }

    @WebMethod(operationName = "viewPatientDetails")
    public String viewPatientDetails(@WebParam(name = "pt_id") String pt_id) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT * FROM patient WHERE pt_id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, pt_id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                StringBuilder result = new StringBuilder();
                result.append("Patient ID: ").append(rs.getString("pt_id")).append("\n")
                        .append("Name: ").append(rs.getString("name")).append("\n")
                        .append("Date of Birth: ").append(rs.getString("dob")).append("\n")
                        .append("Gender: ").append(rs.getString("gender")).append("\n")
                        .append("Marital Status: ").append(rs.getString("marital_status")).append("\n")
                        .append("Nationality: ").append(rs.getString("nationality")).append("\n")
                        .append("Occupation: ").append(rs.getString("occupation")).append("\n")
                        .append("Home Address: ").append(rs.getString("home_add")).append("\n")
                        .append("Phone Number: ").append(rs.getString("phone_no")).append("\n")
                        .append("Email: ").append(rs.getString("email")).append("\n")
                        .append("Visit Date: ").append(rs.getString("visit_date")).append("\n")
                        .append("Visit Time: ").append(rs.getString("visit_time")).append("\n")
                        .append("Emergency Contact Name: ").append(rs.getString("name_emg_contact")).append("\n")
                        .append("Emergency Contact Relation: ").append(rs.getString("relation_emg_contact")).append("\n")
                        .append("Emergency Contact Number: ").append(rs.getString("emg_contact_no")).append("\n")
                        .append("Government ID: ").append(rs.getString("gov_id")).append("\n")
                        .append("Patient Note: ").append(rs.getString("patient_note")).append("\n");
                return result.toString();
            } else {
                return "No patient found with ID " + pt_id;
            }
        } catch (SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to retrieve patient details due to a database error!";
        }
    }
}
