package entities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Athul Krishna
 */
@WebService(serviceName = "reg_staff")
public class reg_staff {

    @WebMethod(operationName = "registerStaff")
    public String registerStaff(
            @WebParam(name = "staff_id") String staff_id,
            @WebParam(name = "First_Name") String firstName,
            @WebParam(name = "Last_Name") String lastName,
            @WebParam(name = "DOB") String dob,
            @WebParam(name = "Gender") String gender,
            @WebParam(name = "Address") String address,
            @WebParam(name = "Phone_No") String phoneNo,
            @WebParam(name = "Email") String email,
            @WebParam(name = "username") String uname,
            @WebParam(name = "password") String pass){

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                // SQL query to insert staff member into the database
                String sql = "INSERT INTO reg_staff (staff_id, First_Name, Last_Name, DOB, Gender, Address, Phone_No, Email, username, password) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                // Create a PreparedStatement
                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, staff_id);
                statement.setString(2, firstName);
                statement.setString(3, lastName);
                statement.setString(4, dob);
                statement.setString(5, gender);
                statement.setString(6, address);
                statement.setString(7, phoneNo);
                statement.setString(8, email);
                statement.setString(9, uname);
                statement.setString(10, pass);

                // Execute the query
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    return "Staff member registered successfully!";
                } else {
                    return "Failed to register staff member!";
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to register staff member due to a database error!";
        }
    }

    @WebMethod(operationName = "deleteStaff")
    public String deleteStaff(@WebParam(name = "staff_id") String staff_id) {
        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                // SQL query to delete staff member from the database
                String sql = "DELETE FROM reg_staff WHERE staff_id = ?";

                // Create a PreparedStatement
                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, staff_id);

                // Execute the query
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    return "Staff member deleted successfully!";
                } else {
                    return "Staff member not found!";
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Database connection error: " + ex.getMessage());
            return "Failed to delete staff member due to a database error!";
        }
    }

    @WebMethod(operationName = "updateStaffField")
    public String updateStaffField(
            @WebParam(name = "staff_id") String staff_id,
            @WebParam(name = "field_name") String field_name,
            @WebParam(name = "new_value") String new_value) {
        StringBuilder result = new StringBuilder();

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                // Make sure the field_name is a valid column in your reg_staff table
                String query = "UPDATE reg_staff SET " + field_name + "=? WHERE staff_id=?";

                // Create a PreparedStatement
                try (PreparedStatement pst = conn.prepareStatement(query)) {
                    pst.setString(1, new_value);
                    pst.setString(2, staff_id);

                    // Execute the query
                    int rowsAffected = pst.executeUpdate();

                    if (rowsAffected > 0) {
                        result.append("Staff member with ID ").append(staff_id)
                                .append(" - ").append(field_name).append(" updated successfully.");
                    } else {
                        result.append("No staff member found with ID ").append(staff_id);
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Database connection error: " + ex.getMessage());
            ex.printStackTrace(); // Print the stack trace for detailed error information
        }

        return result.toString();
    }

    @WebMethod(operationName = "viewStaffDetails")
    public String viewStaffDetails(@WebParam(name = "staff_id") String staff_id) {
        StringBuilder result = new StringBuilder();

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                // Query to retrieve staff details based on staff ID
                String query = "SELECT * FROM reg_staff WHERE staff_id=?";

                // Create a PreparedStatement
                try (PreparedStatement pst = conn.prepareStatement(query)) {
                    pst.setString(1, staff_id);

                    // Execute the query
                    ResultSet rs = pst.executeQuery();

                    // Process the result set
                    if (rs.next()) {
                        result.append("Staff ID: ").append(rs.getString("staff_id")).append("\n")
                                .append("First Name: ").append(rs.getString("First_Name")).append("\n")
                                .append("Last Name: ").append(rs.getString("Last_Name")).append("\n")
                                .append("DOB: ").append(rs.getString("DOB")).append("\n")
                                .append("Gender: ").append(rs.getString("Gender")).append("\n")
                                .append("Address: ").append(rs.getString("Address")).append("\n")
                                .append("Phone No: ").append(rs.getString("Phone_No")).append("\n")
                                .append("Email: ").append(rs.getString("Email")).append("\n");
                    } else {
                        result.append("No staff member found with ID ").append(staff_id);
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Database connection error: " + ex.getMessage());
            ex.printStackTrace(); // Print the stack trace for detailed error information
        }

        return result.toString();
    }

}
